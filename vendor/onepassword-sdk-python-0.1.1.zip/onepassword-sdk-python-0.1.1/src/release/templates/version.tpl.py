SDK_VERSION = "{{ version }}"
SDK_BUILD_NUMBER = "{{ build }}"
